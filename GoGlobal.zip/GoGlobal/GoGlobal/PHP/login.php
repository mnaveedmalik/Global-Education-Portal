<?php
$host = "localhost";
$dbname = "goglobal";
$username = "root";
$password = "";

$conn = mysqli_connect($host, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_POST['email']) && isset($_POST['password'])) {
    $email = $_POST['email'];
    $passwordInput = $_POST['password'];

    $sql = "SELECT * FROM users WHERE email = '$email' AND password = '$passwordInput'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        echo "<h2>Welcome, $email!</h2>";
    } else {
        echo "<h3 style='color:red;'>Incorrect email or password. Or Signup if you are a new User</h3>";
    }
}

mysqli_close($conn);
?>
