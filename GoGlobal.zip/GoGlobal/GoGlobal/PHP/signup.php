<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $conn = mysqli_connect("localhost", "root", "", "goglobal");

    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirmPassword'];
    $day = $_POST['day'];
    $month = $_POST['month'];
    $year = $_POST['year'];
    $gender = $_POST['gender'];

    if ($password !== $confirmPassword) {
        echo "Passwords do not match.";
        exit();
    }

    $dob = "$year-$month-$day";
    $hashedPassword = md5($password); 

    $sql = "INSERT INTO usersignup (firstname, lastname, email, password, dob, gender)
            VALUES ('$firstName', '$lastName', '$email', '$hashedPassword', '$dob', '$gender')";

    if (mysqli_query($conn, $sql)) {
        echo "Your account has been created successfully.";
    } else {
        echo "Error: " . mysqli_error($conn);
    }

    mysqli_close($conn);
}
?>
