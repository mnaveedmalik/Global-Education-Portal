<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "goglobal";

$conn = mysqli_connect($host, $username, $password, $database);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fname = $_POST['first_name'];
    $lname = $_POST['last_name'];
    $email = $_POST['email'];
    $dial = $_POST['dial_code'];
    $phone = $_POST['mobile'];
    $destination = $_POST['destination'];
    $start = $_POST['start_date'];
    $office = $_POST['nearest_office'];
    $counselling = $_POST['counselling_mode'];
    $funding = $_POST['funding'];
    $level = $_POST['study_level'];

    $sql = "INSERT INTO students 
        (first_name, last_name, email, dial_code, mobile, destination, start_date, nearest_office, counselling_mode, funding, study_level)
        VALUES ('$fname', '$lname', '$email', '$dial', '$phone', '$destination', '$start', '$office', '$counselling', '$funding', '$level')";

    if (mysqli_query($conn, $sql)) {
        echo "<h2> Form submitted and data saved successfully!</h2>";
    } else {
        echo "❌ Error: " . mysqli_error($conn);
    }

    mysqli_close($conn);
}
?>
